from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
import sys
import time
import threading
import notify2
# from storage.storage2 import *

class Reminder(QWidget):
	def __init__(self, parent=None):
		super(Reminder, self).__init__()
		notify2.init("Test")
		self.parent = parent
		self.repetition_text = 0
		self.reminder_text = 0
		self.thread_start = 0
		# QMainWindow.__init__(self)
		self.setWindowTitle("Reminder")
		self.setupUI()

	def setupUI(self):
		self.event_name_label = QLabel("Event name", self)
		self.event_name_label.move(5,10)

		self.event_name_edit = QLineEdit(self)
		self.event_name_edit.setPlaceholderText("Event name")
		self.event_name_edit.setMinimumWidth(10)
		self.event_name_edit.move(100,5)

		self.target_date_label = QLabel("Date",self)
		self.target_date_label.move(5, 35)

		self.target_date = QDateEdit(self)
		self.target_date.setDate(QDate.currentDate())
		self.target_date_selected = QDate.currentDate()
		self.target_date.setMinimumDate(QDate.currentDate())
		self.target_date.setCalendarPopup(True)
		self.target_date.setDisplayFormat('dd/MM/yyyy')
		self.target_date.cal = self.target_date.calendarWidget()
		self.target_date.cal.setFirstDayOfWeek(Qt.Monday)
		self.target_date.cal.setHorizontalHeaderFormat(QCalendarWidget.SingleLetterDayNames)
		self.target_date.cal.setVerticalHeaderFormat(QCalendarWidget.NoVerticalHeader)
		self.target_date.cal.setGridVisible(True)
		self.target_date.dateChanged.connect(self.date_selected)
		self.target_date.move(40, 30)
		
		self.target_time_label = QLabel("Time", self)
		self.target_time_label.move(170,35)
		
		self.target_time = QTimeEdit(self)
		self.target_time.setTime(QTime.currentTime())
		self.target_time.timeChanged.connect(self.time_selected)
		self.target_time.move(200,30)
		# self.target_time.setMinimumTime(QTime.currentTime())
		# self.target_time.setTimeRange(QTime(1,0,0,0),QTime(12,59,0,0))

		self.repetition_label = QLabel("Repetition", self)
		self.repetition_label.move(5,60)

		self.repetition = QComboBox(self)
		self.repetition.addItem("One-Time event")
		self.repetition.addItem("Daily")
		self.repetition.addItem("Weekly")
		self.repetition.addItem("Monthly")
		self.repetition.move(100,55)
		self.repetition.setCurrentIndex(0)
		self.repetition.activated.connect(self.repetition_selected)

		self.reminder_label = QLabel("Repetition", self)
		self.reminder_label.move(5,80)

		self.reminder = QComboBox(self)
		self.reminder.addItem("On time")
		self.reminder.addItem("5 mins early")
		self.reminder.addItem("10 mins early")
		self.reminder.addItem("1 hour early")
		self.reminder.addItem("2 hour early")
		self.reminder.addItem("1 day early")
		self.reminder.move(100,80)
		self.reminder.setCurrentIndex(0)
		self.reminder.activated.connect(self.reminder_selected)

		self.add_button = QPushButton("ADD",self)
		self.add_button.move(5,120)
		self.add_button.clicked.connect(self.reminder_added)
		if(self.target_date_selected == QDate.currentDate()):
			self.reminder.model().item(5).setEnabled(False)

		self.setGeometry(400,250,400,200)

	def date_selected(self, date):
		self.target_date_selected = date
		if(self.target_date_selected > QDate.currentDate()):
			self.reminder.model().item(5).setEnabled(True)

	def time_selected(self, time):
		self.target_time_selected = time

	def repetition_selected(self, text):
		self.repetition_text = text
		print(self.repetition_text)

	def reminder_selected(self, text):
		self.reminder_text = text
		print(self.reminder_text)

	def reminder_added(self):
		self.reminder_selection_method()
		self.setVisible(False)
		self.thread_start = 1
		t = threading.Thread(target=self.set_reminder)
		t.start()

	def repetition_selection_method(self):
		if(self.repetition_text == 1):
			self.target_date_selected.setDate(self.target_date_selected.year(),self.target_date_selected.month(),self.target_date_selected.day()+1)
		elif(self.reminder_text == 2):
			self.target_date_selected.setDate(self.target_date_selected.year(),self.target_date_selected.month(),self.target_date_selected.day()+7)
		elif(self.reminder_text == 3):
			self.target_date_selected.setDate(self.target_date_selected.year(),self.target_date_selected.month()+1,self.target_date_selected.day())


	def reminder_selection_method(self):
		if(self.reminder_text == 1):
			self.target_time_selected.setHMS(self.target_time_selected.hour(), self.target_time_selected.minute()-5, 0)
		elif(self.reminder_text == 2):
			self.target_time_selected.setHMS(self.target_time_selected.hour(), self.target_time_selected.minute()-10, 0)
		elif(self.reminder_text == 3):
			self.target_time_selected.setHMS(self.target_time_selected.hour()-1, self.target_time_selected.minute(), 0)
		elif(self.reminder_text == 4):
			self.target_time_selected.setHMS(self.target_time_selected.hour()-2, self.target_time_selected.minute()-5, 0)
		elif(self.reminder_text == 5):
			self.target_date_selected.setDate(self.target_date_selected.year(),self.target_date_selected.month(),self.target_date_selected.day()-1)

	def set_reminder(self):
		print("In thread")
		print(self.target_date_selected)
		while(QDate.currentDate() < self.target_date_selected):
			time.sleep(5)
		print("Date")
		current_time = QTime.currentTime()
		while(current_time.hour() < self.target_time_selected.hour()):
			time.sleep(5)
			current_time = QTime.currentTime()
		print("Hour")
		current_time = QTime.currentTime()
		while(current_time.minute() < self.target_time_selected.minute()):
			time.sleep(5)
			current_time = QTime.currentTime()
		print("Minute")
		notice = notify2.Notification("Message","Its time")
		notice.show()
		# msg = QMessageBox()
		# msg.setText("Its time")
		# msg.setStandardButtons(QMessageBox.Ok)
		#  # msg.buttonClicked.connect(self.close_thread)
		# msg.exec_()
		if(self.repetition_text != 0):
			self.repetition_selection_method()
			self.set_reminder()
		self.close_thread()

	def close_thread(self):
		self.close()
		sys.exit(0)


def main():
	app = QApplication(sys.argv)
	ex = Reminder()
	ex.show()
	app.exec_()
	
if __name__ == '__main__':
	main()






